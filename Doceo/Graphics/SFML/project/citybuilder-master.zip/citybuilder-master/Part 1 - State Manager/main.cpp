#include "game.hpp"

int main()
{
    Game game;

    game.gameLoop();

    return 0;
}
